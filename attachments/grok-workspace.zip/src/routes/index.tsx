import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="hajala-boot">
      <p className="hajala-boot-label">حجالة</p>
      <iframe className="hajala-frame" title="حجالة" src="hajala/index.html" />
    </main>
  );
}
