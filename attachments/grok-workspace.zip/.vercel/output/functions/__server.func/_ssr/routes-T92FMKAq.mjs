import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-T92FMKAq.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "hajala-boot",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "hajala-boot-label",
			children: "حجالة"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			className: "hajala-frame",
			title: "حجالة",
			src: "hajala/index.html"
		})]
	});
}
//#endregion
export { Home as component };
