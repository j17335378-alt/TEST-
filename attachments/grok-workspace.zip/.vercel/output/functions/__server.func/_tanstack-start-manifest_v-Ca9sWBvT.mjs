//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ca9sWBvT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CeASDB4O.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CeASDB4O.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-E7cKiIAi.js"]
	}
} });
//#endregion
export { tsrStartManifest };
