/* حجالة — أنواع الأسئلة: اختيار، صح وخطأ، اذكر */
(function () {
  if (typeof ld !== "function" || typeof sv !== "function" || typeof go !== "function") return;

  const QK = "hajala_questions_v1";
  const TYPES = {
    mcq: { label: "اختر الإجابة الصحيحة", hint: "عدة خيارات، وواحدة منها صحيحة" },
    tf: { label: "صح وخطأ", hint: "العبارة إما صحيحة أو خاطئة" },
    mention: { label: "اذكر", hint: "إجابة مكتوبة، بصياغة واحدة أو عدة نقاط" },
  };

  let QB = null;
  let QDRAFT = null;

  function uid() {
    return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-3);
  }

  function norm(s) {
    return String(s || "")
      .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, "")
      .replace(/[أإآٱ]/g, "ا")
      .replace(/ى/g, "ي")
      .replace(/ؤ/g, "و")
      .replace(/ئ/g, "ي")
      .replace(/ة/g, "ه")
      .replace(/[^\p{L}\p{N}\s]/gu, " ")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function seedBank() {
    return {
      id: "demo",
      title: "نماذج جاهزة",
      at: Date.now(),
      questions: [
        {
          id: "d1",
          type: "mcq",
          prompt: "في أي مدينة تقع الكعبة؟",
          explain: "الكعبة في المسجد الحرام بمكة المكرمة.",
          choices: [
            { id: "d1a", text: "مكة المكرمة" },
            { id: "d1b", text: "المدينة المنورة" },
            { id: "d1c", text: "القدس" },
            { id: "d1d", text: "صنعاء" },
          ],
          correctId: "d1a",
        },
        {
          id: "d2",
          type: "tf",
          prompt: "عدد كواكب المجموعة الشمسية ثمانية.",
          explain: "بعد إعادة تصنيف بلوتو، بقيت الكواكب ثمانية.",
          answer: true,
        },
        {
          id: "d3",
          type: "mention",
          prompt: "اذكر عاصمة اليابان.",
          explain: "العاصمة هي طوكيو، وتُقبل «توكيو» أيضًا.",
          mentionMode: "any",
          answers: ["طوكيو", "توكيو"],
        },
      ],
    };
  }

  function load() {
    if (QB) return QB;
    const saved = ld(QK, null);
    if (!saved || !Array.isArray(saved.banks)) {
      QB = { banks: [seedBank()] };
      sv(QK, QB);
    } else QB = saved;
    return QB;
  }

  function save() {
    sv(QK, QB);
  }

  function bank(id) {
    return load().banks.find((b) => b.id === id) || null;
  }

  function typeLabel(t) {
    return (TYPES[t] && TYPES[t].label) || "سؤال";
  }

  function counts(b) {
    const c = { mcq: 0, tf: 0, mention: 0 };
    (b.questions || []).forEach((q) => {
      if (c[q.type] != null) c[q.type]++;
    });
    return c;
  }

  function countLine(b) {
    const c = counts(b);
    const n = (b.questions || []).length;
    if (!n) return "لا أسئلة بعد";
    return `${n} سؤال · ${c.mcq} اختيار · ${c.tf} صح وخطأ · ${c.mention} اذكر`;
  }

  function blankDraft(type) {
    const d = { id: uid(), type: type || "", prompt: "", explain: "", mentionMode: "any", answer: true, answers: [""], choices: [], correctId: "" };
    if (type) applyType(d, type);
    return d;
  }

  function cloneQ(q) {
    return JSON.parse(JSON.stringify(q));
  }

  function applyType(d, type) {
    d.type = type;
    if (type === "mcq") {
      if (!Array.isArray(d.choices) || d.choices.length < 2) {
        d.choices = [0, 1, 2, 3].map(() => ({ id: uid(), text: "" }));
      }
      if (!d.choices.some((c) => c.id === d.correctId)) d.correctId = d.choices[0].id;
    } else if (type === "tf") {
      if (typeof d.answer !== "boolean") d.answer = true;
    } else if (type === "mention") {
      if (!Array.isArray(d.answers) || !d.answers.length) d.answers = [""];
      if (d.mentionMode !== "all") d.mentionMode = "any";
    }
  }

  function syncDraft() {
    if (!QDRAFT) return;
    const p = document.getElementById("qz-prompt");
    const e = document.getElementById("qz-expl");
    if (p) QDRAFT.prompt = p.value;
    if (e) QDRAFT.explain = e.value;
    if (QDRAFT.type === "mcq") {
      QDRAFT.choices.forEach((c) => {
        const el = document.getElementById("qz-c-" + c.id);
        if (el) c.text = el.value;
      });
      const picked = document.querySelector('input[name="qz-correct"]:checked');
      if (picked) QDRAFT.correctId = picked.value;
    }
    if (QDRAFT.type === "mention") {
      const ta = document.getElementById("qz-answers");
      if (ta) QDRAFT.answers = ta.value.split("\n");
    }
  }

  function backBtn(page, id) {
    const arg = id ? `, {id:'${id}'}` : "";
    return `<button class="btn s" type="button" onclick="go('${page}'${arg})">رجوع</button>`;
  }

  function paintHome() {
    const banks = load().banks;
    const cards = banks.length
      ? banks
          .map((b) => {
            return `<article class="qz-card">
              <div class="qz-q">
                <div>
                  <h3>${esc(b.title)}</h3>
                  <p class="qz-meta">${esc(countLine(b))}</p>
                </div>
              </div>
              <div class="qz-actions">
                <button class="btn" type="button" onclick="qzOpen('${b.id}')">فتح</button>
                <button class="btn s" type="button" onclick="qzRename('${b.id}')">تسمية</button>
                <button class="btn s" type="button" onclick="qzDeleteBank('${b.id}')">حذف</button>
              </div>
            </article>`;
          })
          .join("")
      : `<div class="qz-card"><h3>لا يوجد بنك بعد</h3><p class="qz-meta">أنشئ بنكًا ثم أضف أسئلة من الأنواع الثلاثة.</p></div>`;
    $m.innerHTML = `<div class="qz-wrap">
      <div class="qz-head">
        <div>
          <h2>الأسئلة</h2>
          <p class="qz-sub">اختر نوع كل سؤال: إجابة صحيحة، صح وخطأ، أو اذكر.</p>
        </div>
        <button class="btn" type="button" onclick="qzNewBank()">+ بنك جديد</button>
      </div>
      <div class="qz-types" aria-hidden="true">
        <div class="qz-legend"><b>اختيار</b><small>اختر الإجابة الصحيحة</small></div>
        <div class="qz-legend"><b>صح / خطأ</b><small>حكم على العبارة</small></div>
        <div class="qz-legend"><b>اذكر</b><small>يكتب الإجابة بنفسه</small></div>
      </div>
      <div class="qz-grid">${cards}</div>
    </div>`;
  }

  function paintBank() {
    const b = bank(V.id);
    if (!b) {
      go("quiz");
      return;
    }
    const list = (b.questions || []).length
      ? b.questions
          .map((q, i) => {
            return `<article class="qz-card">
              <div class="qz-q">
                <div>
                  <span class="qz-badge">${esc(typeLabel(q.type))}</span>
                  <p>${esc(q.prompt || "بدون نص")}</p>
                </div>
                <small class="qz-meta">${i + 1}</small>
              </div>
              <div class="qz-actions">
                <button class="btn s" type="button" onclick="qzEdit('${b.id}','${q.id}')">تعديل</button>
                <button class="btn s" type="button" onclick="qzDeleteQ('${b.id}','${q.id}')">حذف</button>
              </div>
            </article>`;
          })
          .join("")
      : `<div class="qz-card"><p class="qz-meta">هذا البنك فاضي. أضف أول سؤال واختر نوعه.</p></div>`;
    const play = (b.questions || []).length
      ? `<button class="btn" type="button" onclick="qzPlay('${b.id}')">ابدأ التدريب</button>`
      : `<button class="btn" type="button" disabled>ابدأ التدريب</button>`;
    $m.innerHTML = `<div class="qz-wrap">
      <div class="qz-head">
        <div>
          <h2>${esc(b.title)}</h2>
          <p class="qz-sub">${esc(countLine(b))}</p>
        </div>
        ${backBtn("quiz")}
      </div>
      <div class="qz-actions">
        <button class="btn" type="button" onclick="qzAdd('${b.id}')">+ سؤال جديد</button>
        ${play}
      </div>
      <div class="qz-grid">${list}</div>
    </div>`;
  }

  function typePicker(selected) {
    return `<div class="qz-grid">${Object.keys(TYPES)
      .map((k) => {
        const t = TYPES[k];
        return `<button class="qz-type${selected === k ? " on" : ""}" type="button" onclick="qzPickType('${k}')">
          <span class="qz-mark">${k === "mcq" ? "أ" : k === "tf" ? "ص" : "ذ"}</span>
          <span><b>${esc(t.label)}</b><small>${esc(t.hint)}</small></span>
        </button>`;
      })
      .join("")}</div>`;
  }

  function paintEdit() {
    const b = bank(V.id);
    if (!b) {
      go("quiz");
      return;
    }
    if (!QDRAFT || QDRAFT._bank !== b.id || QDRAFT._qid !== (V.qid || "")) {
      const existing = V.qid && (b.questions || []).find((q) => q.id === V.qid);
      QDRAFT = existing ? cloneQ(existing) : blankDraft("");
      QDRAFT._bank = b.id;
      QDRAFT._qid = V.qid || "";
    }
    if (!QDRAFT.type) {
      $m.innerHTML = `<div class="qz-wrap">
        <div class="qz-head">
          <div>
            <h2>نوع السؤال</h2>
            <p class="qz-sub">اختَر شكل السؤال قبل كتابة الخيارات.</p>
          </div>
          ${backBtn("qbank", b.id)}
        </div>
        ${typePicker("")}
      </div>`;
      return;
    }
    const d = QDRAFT;
    let body = "";
    if (d.type === "mcq") {
      body = `<p class="qz-label">الخيارات — حدّد الإجابة الصحيحة</p>
        <div class="qz-grid">${d.choices
          .map(
            (c, i) => `<div class="qz-choice">
            <label class="qz-radio"><input type="radio" name="qz-correct" value="${c.id}" ${c.id === d.correctId ? "checked" : ""}><span>صحيحة</span></label>
            <input id="qz-c-${c.id}" type="text" maxlength="180" placeholder="الخيار ${i + 1}" value="${esc(c.text || "")}">
            <button class="btn s" type="button" onclick="qzRemoveChoice('${c.id}')">حذف</button>
          </div>`,
          )
          .join("")}</div>
        <button class="btn s" type="button" onclick="qzAddChoice()" ${d.choices.length >= 6 ? "disabled" : ""}>إضافة خيار</button>`;
    } else if (d.type === "tf") {
      body = `<p class="qz-label">الإجابة الصحيحة</p>
        <div class="qz-seg">
          <button class="qz-opt${d.answer === true ? " on" : ""}" type="button" data-tf="true" onclick="qzSetTf(true)">صح</button>
          <button class="qz-opt${d.answer === false ? " on" : ""}" type="button" data-tf="false" onclick="qzSetTf(false)">خطأ</button>
        </div>`;
    } else {
      body = `<p class="qz-label">طريقة التصحيح</p>
        <div class="qz-seg">
          <button class="qz-opt${d.mentionMode !== "all" ? " on" : ""}" type="button" onclick="qzMentionMode('any')">تكفي أي صياغة</button>
          <button class="qz-opt${d.mentionMode === "all" ? " on" : ""}" type="button" onclick="qzMentionMode('all')">يجب ذكر كل النقاط</button>
        </div>
        <label class="qz-label" for="qz-answers">${d.mentionMode === "all" ? "النقاط المطلوبة — كل نقطة في سطر" : "الإجابات المقبولة — كل صياغة في سطر"}</label>
        <textarea id="qz-answers" rows="4" maxlength="800" placeholder="طوكيو&#10;توكيو">${esc((d.answers || []).join("\n"))}</textarea>`;
    }
    $m.innerHTML = `<div class="qz-wrap">
      <div class="qz-head">
        <div>
          <h2>${V.qid ? "تعديل السؤال" : "سؤال جديد"}</h2>
          <p class="qz-sub">${esc(b.title)}</p>
        </div>
        ${backBtn("qbank", b.id)}
      </div>
      <p class="qz-label">النوع</p>
      ${typePicker(d.type)}
      <label class="qz-label" for="qz-prompt">نص السؤال</label>
      <textarea id="qz-prompt" rows="3" maxlength="600" placeholder="${d.type === "tf" ? "اكتب العبارة التي يُحكم عليها" : d.type === "mention" ? "مثال: اذكر عاصمة اليابان" : "اكتب السؤال"}">${esc(d.prompt || "")}</textarea>
      ${body}
      <label class="qz-label" for="qz-expl">تفسير يظهر بعد الإجابة (اختياري)</label>
      <textarea id="qz-expl" rows="2" maxlength="400" placeholder="لماذا هذه هي الإجابة؟">${esc(d.explain || "")}</textarea>
      <div class="qz-actions">
        <button class="btn" type="button" onclick="qzSave()">حفظ السؤال</button>
        ${V.qid ? `<button class="btn s" type="button" onclick="qzDeleteQ('${b.id}','${V.qid}')">حذف</button>` : ""}
      </div>
    </div>`;
  }

  function modelAnswer(q) {
    if (q.type === "mcq") {
      const c = (q.choices || []).find((x) => x.id === q.correctId);
      return c ? c.text : "";
    }
    if (q.type === "tf") return q.answer ? "صح" : "خطأ";
    const lines = (q.answers || []).map((a) => String(a || "").trim()).filter(Boolean);
    return lines.join(q.mentionMode === "all" ? " + " : " أو ");
  }

  function gradeMention(q, text) {
    const n = norm(text);
    const points = (q.answers || [])
      .map((a) => ({ raw: String(a || "").trim(), n: norm(a) }))
      .filter((p) => p.n);
    const hit = points.map((p) => ({ ...p, ok: !!n && (n === p.n || (p.n.length >= 2 && n.includes(p.n))) }));
    const ok = q.mentionMode === "all" ? hit.length > 0 && hit.every((p) => p.ok) : hit.some((p) => p.ok);
    return { ok, hit };
  }

  function grade(q, choice) {
    if (q.type === "mcq") return choice === q.correctId;
    if (q.type === "tf") return choice === q.answer;
    return gradeMention(q, choice).ok;
  }

  function paintPlay() {
    const b = bank(V.id);
    const play = window.__qzPlay;
    if (!b || !play || play.bankId !== b.id) {
      go("qbank", { id: V.id });
      return;
    }
    if (play.done) {
      const total = play.ids.length;
      const misses = play.wrong
        .map((id) => (b.questions || []).find((q) => q.id === id))
        .filter(Boolean)
        .map((q) => `<li><span class="qz-badge">${esc(typeLabel(q.type))}</span> ${esc(q.prompt)}</li>`)
        .join("");
      $m.innerHTML = `<div class="qz-wrap">
        <div class="qz-head"><div><h2>النتيجة</h2><p class="qz-sub">${esc(b.title)}</p></div>${backBtn("qbank", b.id)}</div>
        <div class="qz-score"><b>${play.score}</b><small>من ${total}</small></div>
        ${misses ? `<div class="qz-card"><h3>راجِع هذه</h3><ul class="qz-miss">${misses}</ul></div>` : `<div class="qz-card"><h3>إجابات كاملة</h3><p class="qz-meta">كل الأسئلة كانت صحيحة.</p></div>`}
        <div class="qz-actions">
          <button class="btn" type="button" onclick="qzPlay('${b.id}')">إعادة التدريب</button>
          <button class="btn s" type="button" onclick="go('qbank',{id:'${b.id}'})">العودة للبنك</button>
        </div>
      </div>`;
      return;
    }
    const q = (b.questions || []).find((x) => x.id === play.ids[play.i]);
    if (!q) {
      play.done = true;
      paintPlay();
      return;
    }
    const pct = Math.round((play.i / play.ids.length) * 100);
    let controls = "";
    if (q.type === "mcq") {
      controls = (q.choices || [])
        .map((c) => {
          let cls = "qz-opt";
          if (play.revealed && c.id === q.correctId) cls += " good";
          else if (play.revealed && c.id === play.choice && c.id !== q.correctId) cls += " bad";
          else if (!play.revealed && c.id === play.choice) cls += " on";
          const click = play.revealed ? "" : `onclick="qzAnswer('${c.id}')"`;
          return `<button class="${cls}" type="button" ${click}>${esc(c.text || "—")}</button>`;
        })
        .join("");
    } else if (q.type === "tf") {
      controls = ["صح", "خطأ"]
        .map((label, idx) => {
          const val = idx === 0;
          let cls = "qz-opt";
          if (play.revealed && val === q.answer) cls += " good";
          else if (play.revealed && play.choice === val && val !== q.answer) cls += " bad";
          else if (!play.revealed && play.choice === val) cls += " on";
          const click = play.revealed ? "" : `onclick="qzAnswer(${val})"`;
          return `<button class="${cls}" type="button" ${click}>${label}</button>`;
        })
        .join("");
      controls = `<div class="qz-seg">${controls}</div>`;
    } else {
      const locked = play.revealed ? "disabled" : "";
      controls = `<textarea id="qz-live" rows="4" maxlength="600" placeholder="اكتب ما تذكره هنا" ${locked}>${esc(play.choice || "")}</textarea>
        ${play.revealed ? "" : `<button class="btn" type="button" onclick="qzCheckMention()">تحقق</button>`}`;
      if (play.revealed) {
        const rep = gradeMention(q, play.choice || "");
        const bits = rep.hit
          .map((p) => `<li class="${p.ok ? "good" : "bad"}">${esc(p.raw)} — ${p.ok ? "مذكورة" : "ناقصة"}</li>`)
          .join("");
        if (q.mentionMode === "all" && bits) controls += `<ul class="qz-miss">${bits}</ul>`;
      }
    }
    const banner = play.revealed
      ? `<div class="qz-banner ${play.lastOk ? "good" : "bad"}">
          <b>${play.lastOk ? "إجابة صحيحة" : "ليست الإجابة المطلوبة"}</b>
          <p>الإجابة: ${esc(modelAnswer(q) || "—")}</p>
          ${q.explain ? `<p class="qz-meta">${esc(q.explain)}</p>` : ""}
        </div>
        <button class="btn" type="button" onclick="qzNext()">${play.i + 1 >= play.ids.length ? "النتيجة" : "التالي"}</button>`
      : "";
    $m.innerHTML = `<div class="qz-wrap">
      <div class="qz-head">
        <div>
          <h2>تدريب</h2>
          <p class="qz-sub">${esc(b.title)} · ${play.i + 1} / ${play.ids.length}</p>
        </div>
        <button class="btn s" type="button" onclick="go('qbank',{id:'${b.id}'})">خروج</button>
      </div>
      <div class="qz-progress" aria-hidden="true"><span style="width:${pct}%"></span></div>
      <article class="qz-card">
        <span class="qz-badge">${esc(typeLabel(q.type))}</span>
        <h3>${esc(q.prompt)}</h3>
      </article>
      <div class="qz-grid">${controls}</div>
      ${banner}
    </div>`;
  }

  function qzPaint() {
    if (V.p === "quiz") paintHome();
    else if (V.p === "qbank") paintBank();
    else if (V.p === "qedit") paintEdit();
    else if (V.p === "qplay") paintPlay();
  }

  function qzMarkNav() {
    const navEl = document.getElementById("nav");
    if (!navEl) return;
    let b = navEl.querySelector("[data-qz-nav]");
    if (!b) {
      b = document.createElement("button");
      b.type = "button";
      b.dataset.qzNav = "1";
      b.textContent = "الأسئلة";
      b.addEventListener("click", () => go("quiz"));
      const admin = [...navEl.children].find((el) => (el.textContent || "").includes("إدارة"));
      if (admin) navEl.insertBefore(b, admin);
      else navEl.appendChild(b);
    }
    const on = V && (V.p === "quiz" || V.p === "qbank" || V.p === "qedit" || V.p === "qplay");
    b.classList.toggle("on", !!on);
  }

  window.qzNewBank = function () {
    adPrompt("بنك أسئلة جديد", "", "إنشاء", (title) => {
      const b = { id: uid(), title, at: Date.now(), questions: [] };
      load().banks.unshift(b);
      save();
      QDRAFT = null;
      go("qbank", { id: b.id });
      msg("تم إنشاء البنك");
    });
  };

  window.qzOpen = function (id) {
    QDRAFT = null;
    go("qbank", { id });
  };

  window.qzRename = function (id) {
    const b = bank(id);
    if (!b) return;
    adPrompt("اسم البنك", b.title, "حفظ", (title) => {
      b.title = title;
      save();
      render();
    });
  };

  window.qzDeleteBank = function (id) {
    const b = bank(id);
    if (!b) return;
    adAsk("حذف البنك", `سيُحذف «${b.title}» وكل أسئلته.`, "حذف", () => {
      QB.banks = QB.banks.filter((x) => x.id !== id);
      save();
      render();
    });
  };

  window.qzAdd = function (id) {
    QDRAFT = null;
    go("qedit", { id, qid: "" });
  };

  window.qzEdit = function (bankId, qid) {
    QDRAFT = null;
    go("qedit", { id: bankId, qid });
  };

  window.qzPickType = function (type) {
    if (!TYPES[type] || !QDRAFT) return;
    if (QDRAFT.type === type) return;
    syncDraft();
    applyType(QDRAFT, type);
    render();
  };

  window.qzSetTf = function (v) {
    if (!QDRAFT) return;
    QDRAFT.answer = !!v;
    document.querySelectorAll("[data-tf]").forEach((el) => {
      el.classList.toggle("on", String(!!v) === el.getAttribute("data-tf"));
    });
  };

  window.qzMentionMode = function (mode) {
    if (!QDRAFT) return;
    syncDraft();
    QDRAFT.mentionMode = mode === "all" ? "all" : "any";
    render();
  };

  window.qzAddChoice = function () {
    if (!QDRAFT || QDRAFT.type !== "mcq") return;
    syncDraft();
    if (QDRAFT.choices.length >= 6) return;
    QDRAFT.choices.push({ id: uid(), text: "" });
    render();
  };

  window.qzRemoveChoice = function (id) {
    if (!QDRAFT) return;
    syncDraft();
    if (QDRAFT.choices.length <= 2) {
      msg("خياران على الأقل");
      return;
    }
    QDRAFT.choices = QDRAFT.choices.filter((c) => c.id !== id);
    if (!QDRAFT.choices.some((c) => c.id === QDRAFT.correctId)) QDRAFT.correctId = QDRAFT.choices[0].id;
    render();
  };

  window.qzSave = function () {
    if (!QDRAFT) return;
    syncDraft();
    const b = bank(QDRAFT._bank);
    if (!b) return;
    const prompt = String(QDRAFT.prompt || "").trim();
    if (!prompt) {
      msg("اكتب نص السؤال");
      return;
    }
    const q = {
      id: QDRAFT._qid || QDRAFT.id || uid(),
      type: QDRAFT.type,
      prompt,
      explain: String(QDRAFT.explain || "").trim(),
    };
    if (q.type === "mcq") {
      const choices = (QDRAFT.choices || [])
        .map((c) => ({ id: c.id, text: String(c.text || "").trim() }))
        .filter((c) => c.text);
      if (choices.length < 2) {
        msg("أضف خيارين على الأقل");
        return;
      }
      if (!choices.some((c) => c.id === QDRAFT.correctId)) {
        msg("حدّد الإجابة الصحيحة");
        return;
      }
      q.choices = choices;
      q.correctId = QDRAFT.correctId;
    } else if (q.type === "tf") {
      q.answer = !!QDRAFT.answer;
    } else if (q.type === "mention") {
      const answers = (QDRAFT.answers || []).map((a) => String(a || "").trim()).filter(Boolean);
      if (!answers.length) {
        msg(QDRAFT.mentionMode === "all" ? "اكتب نقطة واحدة على الأقل" : "اكتب إجابة مقبولة واحدة على الأقل");
        return;
      }
      q.mentionMode = QDRAFT.mentionMode === "all" ? "all" : "any";
      q.answers = answers.slice(0, 12);
    } else {
      msg("اختر نوع السؤال");
      return;
    }
    const i = (b.questions || []).findIndex((x) => x.id === q.id);
    if (i >= 0) b.questions[i] = q;
    else {
      b.questions = b.questions || [];
      b.questions.push(q);
    }
    save();
    QDRAFT = null;
    go("qbank", { id: b.id });
    msg("تم حفظ السؤال");
  };

  window.qzDeleteQ = function (bankId, qid) {
    const b = bank(bankId);
    const q = b && (b.questions || []).find((x) => x.id === qid);
    if (!q) return;
    adAsk("حذف السؤال", "سيُحذف هذا السؤال من البنك.", "حذف", () => {
      b.questions = b.questions.filter((x) => x.id !== qid);
      save();
      QDRAFT = null;
      go("qbank", { id: bankId });
    });
  };

  window.qzPlay = function (id) {
    const b = bank(id);
    if (!b || !(b.questions || []).length) {
      msg("أضف سؤالًا أولًا");
      return;
    }
    window.__qzPlay = { bankId: id, ids: b.questions.map((q) => q.id), i: 0, score: 0, revealed: false, choice: null, wrong: [], done: false, lastOk: false };
    go("qplay", { id });
  };

  window.qzAnswer = function (choice) {
    const play = window.__qzPlay;
    if (!play || play.revealed) return;
    const b = bank(play.bankId);
    const q = b && (b.questions || []).find((x) => x.id === play.ids[play.i]);
    if (!q) return;
    play.choice = choice;
    play.revealed = true;
    play.lastOk = grade(q, choice);
    if (play.lastOk) play.score++;
    else play.wrong.push(q.id);
    render();
  };

  window.qzCheckMention = function () {
    const ta = document.getElementById("qz-live");
    const text = ta ? ta.value.trim() : "";
    if (!text) {
      msg("اكتب إجابتك أولًا");
      return;
    }
    window.qzAnswer(text);
  };

  window.qzNext = function () {
    const play = window.__qzPlay;
    if (!play) return;
    play.i++;
    play.revealed = false;
    play.choice = null;
    if (play.i >= play.ids.length) play.done = true;
    render();
  };

  const origNav = nav;
  nav = function () {
    const r = origNav.apply(this, arguments);
    try {
      qzMarkNav();
    } catch (e) {
      console.debug("[hajala]", e);
    }
    return r;
  };

  const origRender = render;
  render = function () {
    const p = typeof V !== "undefined" && V ? V.p : "";
    const mine = p === "quiz" || p === "qbank" || p === "qedit" || p === "qplay";
    const r = origRender.apply(this, arguments);
    if (mine) {
      try {
        qzPaint();
      } catch (err) {
        console.error(err);
        if (typeof $m !== "undefined" && $m) $m.innerHTML = '<div class="box empty">تعذّر فتح الأسئلة.</div>';
      }
    }
    return r;
  };

  if (typeof hajalaMainDashboard === "function") {
    const origDash = hajalaMainDashboard;
    hajalaMainDashboard = function () {
      const html = origDash.apply(this, arguments);
      if (!html || html.includes("data-qz-short")) return html;
      const btn = `<button class="hj-shortcut" data-qz-short="1" onclick="go('quiz')"><span class="hj-ico"><svg class="hj-svg-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 6h11M8 12h11M8 18h7"/><path d="M4.5 6h.01M4.5 12h.01M4.5 18h.01"/></svg></span><b>الأسئلة</b></button>`;
      const needle = `<button class="hj-shortcut" onclick="go('admin')">`;
      return html.includes(needle) ? html.replace(needle, btn + needle) : html;
    };
  }

  const style = document.createElement("style");
  style.textContent = `
.qz-wrap{display:flex;flex-direction:column;gap:12px}
.qz-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}
.qz-head h2,.qz-card h3{margin:0}
.qz-head h2{font-size:1.35rem}
.qz-sub,.qz-meta{color:var(--mu);margin:4px 0 0;font-size:.9rem}
.qz-grid{display:flex;flex-direction:column;gap:10px}
.qz-card{background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:14px;display:flex;flex-direction:column;gap:10px}
.qz-card h3{font-size:1.05rem;line-height:1.45}
.qz-q{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}
.qz-q p{margin:8px 0 0}
.qz-actions,.qz-seg{display:flex;flex-wrap:wrap;gap:8px}
.qz-seg{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.qz-types{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.qz-legend{background:var(--on);border:1px solid var(--bd);border-radius:14px;padding:10px 12px}
.qz-legend b{display:block}
.qz-legend small,.qz-type small{color:var(--mu)}
.qz-type{display:flex;gap:12px;align-items:center;width:100%;text-align:right;background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:12px 14px;cursor:pointer;min-height:72px}
.qz-type.on{border-color:var(--ac);box-shadow:inset 0 0 0 1px var(--ac)}
.qz-type b{display:block}
.qz-mark{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:var(--on);color:var(--ac);border:1px solid var(--bd);flex:none;font-weight:700}
.qz-badge{display:inline-flex;align-items:center;border-radius:999px;padding:2px 10px;font-size:.75rem;border:1px solid var(--bd);color:var(--ac);background:var(--on)}
.qz-label{display:block;margin-top:4px;font-weight:600}
.qz-wrap textarea,.qz-choice input[type=text]{width:100%;background:var(--on);border:1px solid var(--bd);border-radius:12px;padding:10px 12px}
.qz-choice{display:flex;gap:8px;align-items:center}
.qz-choice input[type=text]{flex:1;min-width:0}
.qz-radio{display:flex;flex-direction:column;align-items:center;gap:2px;font-size:.72rem;color:var(--mu);min-width:52px}
.qz-opt{width:100%;text-align:right;background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:12px 14px;min-height:48px;cursor:pointer}
.qz-opt.on,.qz-opt.good{border-color:var(--ac);box-shadow:inset 0 0 0 1px var(--ac)}
.qz-opt.bad{border-color:var(--romance-rose);box-shadow:inset 0 0 0 1px var(--romance-rose)}
.qz-banner{border-radius:14px;padding:12px 14px;background:var(--on);border:1px solid var(--bd)}
.qz-banner.good{border-color:var(--ac)}
.qz-banner.bad{border-color:var(--romance-rose)}
.qz-banner p{margin:6px 0 0}
.qz-progress{height:6px;border-radius:99px;background:var(--bd);overflow:hidden}
.qz-progress span{display:block;height:100%;background:var(--ac)}
.qz-score{background:var(--card);border:1px solid var(--bd);border-radius:18px;padding:18px;text-align:center}
.qz-score b{display:block;font-size:2.4rem;color:var(--ac);line-height:1}
.qz-miss{margin:8px 0 0;padding:0 18px 0 0}
.qz-miss li{margin:6px 0}
.qz-miss li.good{color:var(--ac)}
.qz-miss li.bad{color:var(--romance-rose)}
.qz-wrap button:disabled{opacity:.45;cursor:default}
.hj-shortcuts:has([data-qz-short]){grid-template-columns:repeat(3,minmax(0,1fr))}
@media(min-width:840px){.hj-shortcuts:has([data-qz-short]){grid-template-columns:repeat(6,minmax(0,1fr))}}
@media(max-width:560px){.qz-types{grid-template-columns:1fr}.qz-choice{flex-wrap:wrap}}
`;
  document.head.appendChild(style);

  const enter = document.getElementById("hj-enter-btn");
  if (enter) {
    const hop = () => {
      if (!enter.hidden && !enter.disabled) enter.click();
    };
    new MutationObserver(hop).observe(enter, { attributes: true, attributeFilter: ["hidden", "disabled"] });
    hop();
  }
})();
